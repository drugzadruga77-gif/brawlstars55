---
name: Brawl Stars external API integration
description: Quirks of the official Brawl Stars Developer API relevant to any feature that calls it (player profile, battle log, stats).
---

- The official API is IP-locked: keys must be created at developer.brawlstars.com bound to the server's outbound IP, or all requests 403.
- Player tags must be URL-encoded as `%23` + tag (uppercase, no literal '#') when calling `https://api.brawlstars.com/v1/players/%23TAG`.
- Battle log timestamps come back in the compact form `YYYYMMDDTHHmmss.SSSZ`, not standard ISO-8601 — must be reformatted before passing to `Date`/Zod `coerce.date()`.
- The battle log endpoint only retains roughly the last ~25 battles, so any "today" stats derived from it are a best-effort estimate, not a complete daily total — surface this caveat in the UI rather than hiding it.
- `hypercharges` and gear `level` are not guaranteed present on every brawler in the raw payload; default to empty array / level 1 rather than erroring.

**Why:** discovered while building a Brawl Stars player-stats site; getting any of these wrong silently breaks stats for real player tags.
**How to apply:** any future feature that calls the Brawl Stars Developer API (new endpoints, caching layer, etc.) should reuse these conventions instead of re-deriving them.
