# Memory Index

- [Brawl Stars external API integration](brawl-stats-api.md) — auth, tag encoding, and battle-time parsing quirks when calling the official Brawl Stars API.
